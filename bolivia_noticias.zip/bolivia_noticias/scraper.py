"""
scraper.py
==========
Crawler y parser para Los Tiempos y Red Uno.

Flujo:
  1. Lee la portada de cada portal y extrae links de noticias.
  2. Sigue cada link y extrae: título, URL y cuerpo limpio.
  3. Guarda en la base de datos con control de versiones.

Estrategias anti-bloqueo:
  - Rotación de User-Agents con la librería fake-useragent.
  - Delay aleatorio de 2-4 segundos entre peticiones.
  - Headers que imitan un navegador real (Accept, Accept-Language, etc.).
  - Sesión persistente de requests para reutilizar conexiones TCP.
"""

import time
import random
import logging
from datetime import datetime
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

from database import DatabaseManager

# ------------------------------------------------------------------
# Configuración de logging
# ------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

# ------------------------------------------------------------------
# Constantes de configuración
# ------------------------------------------------------------------
DELAY_MIN = 2.0   # segundos mínimos entre peticiones
DELAY_MAX = 4.0   # segundos máximos entre peticiones
TIMEOUT   = 15    # segundos para timeout de cada request
MAX_NOTICIAS_POR_PORTAL = 20  # límite por ejecución para no sobrecargar

PORTALES = {
    "Los Tiempos": {
        "portada": "https://www.lostiempos.com/actualidad",
        "dominio":  "https://www.lostiempos.com",
        "parser":   "parsear_lostiempos",
    },
    "Red Uno": {
        "portada": "https://www.reduno.com.bo/noticias",
        "dominio":  "https://www.reduno.com.bo",
        "parser":   "parsear_reduno",
    },
}

# ------------------------------------------------------------------
# Helpers de HTTP
# ------------------------------------------------------------------
ua = UserAgent()   # Generador de User-Agents


def _headers_aleatorios() -> dict:
    """
    Construye headers que imitan un navegador real.
    El User-Agent rota en cada llamada.
    """
    return {
        "User-Agent":      ua.random,
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-BO,es;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection":      "keep-alive",
        "DNT":             "1",            # Do Not Track (señal de privacidad)
        "Upgrade-Insecure-Requests": "1",
    }


def _pausa():
    """Espera un tiempo aleatorio entre DELAY_MIN y DELAY_MAX segundos."""
    t = random.uniform(DELAY_MIN, DELAY_MAX)
    log.debug(f"Esperando {t:.1f}s...")
    time.sleep(t)


def _get(session: requests.Session, url: str) -> BeautifulSoup | None:
    """
    Hace una petición GET y devuelve un objeto BeautifulSoup.
    Retorna None si falla (timeout, error HTTP, etc.).
    """
    try:
        resp = session.get(url, headers=_headers_aleatorios(), timeout=TIMEOUT)
        resp.raise_for_status()
        return BeautifulSoup(resp.text, "html.parser")
    except requests.exceptions.Timeout:
        log.warning(f"Timeout al acceder a: {url}")
    except requests.exceptions.HTTPError as e:
        log.warning(f"Error HTTP {e.response.status_code} en: {url}")
    except requests.exceptions.RequestException as e:
        log.warning(f"Error de conexión en {url}: {e}")
    return None


# ------------------------------------------------------------------
# Parsers de portada (extracción de links)
# ------------------------------------------------------------------

def _links_lostiempos(soup: BeautifulSoup, dominio: str) -> list[str]:
    """
    Extrae links de noticias de la portada de Los Tiempos.
    Los artículos están en <a> dentro de contenedores de noticias,
    y siguen el patrón /actualidad/ o /hoy/.
    """
    links = set()
    for a in soup.find_all("a", href=True):
        href = a["href"]
        # Los Tiempos usa URLs relativas o absolutas con su dominio
        if href.startswith("/"):
            href = urljoin(dominio, href)
        # Filtrar solo links de noticias (excluir servicios, hemeroteca, etc.)
        partes = urlparse(href)
        segmentos = partes.path.strip("/").split("/")
        # Noticias tienen: /seccion/subseccion/fecha/slug  (≥ 3 segmentos)
        if (
            "lostiempos.com" in partes.netloc
            and len(segmentos) >= 3
            and any(s in segmentos[0] for s in ["actualidad", "hoy", "cochabamba", "pais"])
            and not any(excl in href for excl in ["#", "javascript", "mailto", "/rss", "/servicios"])
        ):
            links.add(href)
    return list(links)[:MAX_NOTICIAS_POR_PORTAL]


def _links_reduno(soup: BeautifulSoup, dominio: str) -> list[str]:
    """
    Extrae links de noticias de la portada de Red Uno.
    Las noticias están en <article class="nota"> con links internos.
    """
    links = set()
    # Método 1: buscar en elementos <article class="nota">
    for article in soup.find_all("article", class_=lambda c: c and "nota" in c):
        a = article.find("a", href=True)
        if a:
            href = a["href"]
            if href.startswith("/"):
                href = urljoin(dominio, href)
            if "reduno.com.bo" in href:
                links.add(href)

    # Método 2: buscar <a> con href que parezcan artículos (tienen fecha en slug)
    if len(links) < 5:
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if href.startswith("/"):
                href = urljoin(dominio, href)
            partes = urlparse(href)
            # Los slugs de Red Uno terminan con -YYYYMMDDHHMMSS
            if (
                "reduno.com.bo" in partes.netloc
                and len(partes.path) > 20
                and any(char.isdigit() for char in partes.path[-15:])
                and not any(excl in href for excl in ["#", "javascript", "mailto"])
            ):
                links.add(href)

    return list(links)[:MAX_NOTICIAS_POR_PORTAL]


# ------------------------------------------------------------------
# Parsers de artículo (extracción de contenido)
# ------------------------------------------------------------------

def parsear_lostiempos(soup: BeautifulSoup, url: str) -> dict | None:
    """
    Extrae título y cuerpo de una noticia de Los Tiempos.

    Estructura Drupal 7:
      - Título: <h1 class="page-header"> o <meta property="og:title">
      - Cuerpo:  <div class="field-name-body"> > <div class="field-items"> > <div class="field-item">
    """
    # Título
    titulo = None
    h1 = soup.find("h1", class_="page-header")
    if h1:
        titulo = h1.get_text(strip=True)
    else:
        og_title = soup.find("meta", property="og:title")
        if og_title:
            titulo = og_title.get("content", "").strip()

    if not titulo:
        log.debug(f"Sin título en: {url}")
        return None

    # Cuerpo del artículo
    cuerpo_div = soup.find("div", class_="field-name-body")
    if not cuerpo_div:
        log.debug(f"Sin cuerpo (field-name-body) en: {url}")
        return None

    # Extraer solo los párrafos <p> del cuerpo (evita menús y publicidad)
    parrafos = cuerpo_div.find_all("p")
    texto = " ".join(p.get_text(" ", strip=True) for p in parrafos if p.get_text(strip=True))

    if len(texto) < 100:
        log.debug(f"Texto demasiado corto en: {url}")
        return None

    # Fecha de publicación desde meta tag
    fecha_pub = None
    meta_fecha = soup.find("meta", property="article:published_time")
    if meta_fecha:
        fecha_pub = meta_fecha.get("content", "")[:10]  # solo YYYY-MM-DD

    return {"titulo": titulo, "texto": texto, "fecha_pub": fecha_pub}


def parsear_reduno(soup: BeautifulSoup, url: str) -> dict | None:
    """
    Extrae título y cuerpo de una noticia de Red Uno (portal AMP).

    Estructura AMP:
      - Título: <h1 class="titulo"> o <meta property="og:title">
      - Cuerpo:  <div class="body__cuerpo"> — contiene <p> con el texto,
                 pero también <article> de notas relacionadas que hay que excluir.
    """
    # Título
    titulo = None
    h1 = soup.find("h1", class_=lambda c: c and "titulo" in c)
    if h1:
        titulo = h1.get_text(strip=True)
    else:
        og_title = soup.find("meta", property="og:title")
        if og_title:
            titulo = og_title.get("content", "").strip()

    if not titulo:
        log.debug(f"Sin título en: {url}")
        return None

    # Cuerpo del artículo
    cuerpo_div = soup.find("div", class_="body__cuerpo")
    if not cuerpo_div:
        log.debug(f"Sin cuerpo (body__cuerpo) en: {url}")
        return None

    # Eliminar elementos no deseados DENTRO del cuerpo:
    # - <article> de notas relacionadas embebidas
    # - <div> de publicidad
    # - <div class="link_nota_propia"> (links a otras notas)
    for elemento in cuerpo_div.find_all(
        ["article", "div"],
        class_=lambda c: c and any(
            cls in c for cls in ["nota", "publi", "link_nota", "container_publi", "body__texto-final"]
        ),
    ):
        elemento.decompose()

    # Extraer párrafos limpios
    parrafos = cuerpo_div.find_all("p")
    texto = " ".join(p.get_text(" ", strip=True) for p in parrafos if p.get_text(strip=True))

    if len(texto) < 100:
        log.debug(f"Texto demasiado corto en: {url}")
        return None

    # Fecha de publicación
    fecha_pub = None
    meta_fecha = soup.find("meta", property="article:published_time")
    if meta_fecha:
        fecha_pub = meta_fecha.get("content", "")[:10]

    return {"titulo": titulo, "texto": texto, "fecha_pub": fecha_pub}


# ------------------------------------------------------------------
# Función principal del scraper
# ------------------------------------------------------------------

def ejecutar_scraping(db: DatabaseManager = None) -> dict:
    """
    Ejecuta el ciclo completo de scraping para todos los portales.

    Retorna un resumen con conteos por resultado para el log/dashboard.
    """
    if db is None:
        db = DatabaseManager()

    session = requests.Session()
    resumen = {"nuevas": 0, "actualizadas": 0, "sin_cambios": 0, "errores": 0}

    for nombre_portal, config in PORTALES.items():
        log.info(f"═══ Iniciando scraping: {nombre_portal} ═══")

        # 1. Leer portada
        soup_portada = _get(session, config["portada"])
        if soup_portada is None:
            log.error(f"No se pudo acceder a la portada de {nombre_portal}")
            resumen["errores"] += 1
            continue

        _pausa()

        # 2. Extraer links de noticias
        if nombre_portal == "Los Tiempos":
            links = _links_lostiempos(soup_portada, config["dominio"])
        else:
            links = _links_reduno(soup_portada, config["dominio"])

        log.info(f"  Encontrados {len(links)} links en {nombre_portal}")

        # 3. Procesar cada noticia
        parser_func = parsear_lostiempos if nombre_portal == "Los Tiempos" else parsear_reduno

        for i, url in enumerate(links, 1):
            log.info(f"  [{i}/{len(links)}] Procesando: {url[:80]}...")
            soup_noticia = _get(session, url)

            if soup_noticia is None:
                resumen["errores"] += 1
                _pausa()
                continue

            datos = parser_func(soup_noticia, url)
            if datos is None:
                resumen["errores"] += 1
                _pausa()
                continue

            resultado = db.guardar_noticia(
                url=url,
                titulo=datos["titulo"],
                texto=datos["texto"],
                fuente=nombre_portal,
                fecha_pub=datos.get("fecha_pub"),
            )
            resumen[resultado if resultado != "actualizada" else "actualizadas"] += 1
            resumen[resultado] = resumen.get(resultado, 0) + 1
            log.info(f"    → {resultado}: {datos['titulo'][:60]}")
            _pausa()

    log.info(f"Scraping completo. Resumen: {resumen}")
    return resumen


# ------------------------------------------------------------------
# Ejecución directa para pruebas
# ------------------------------------------------------------------
if __name__ == "__main__":
    print("Iniciando scraping de prueba...")
    print("(Esto puede tardar varios minutos por los delays anti-bloqueo)\n")
    resumen = ejecutar_scraping()
    print(f"\nResumen final: {resumen}")
